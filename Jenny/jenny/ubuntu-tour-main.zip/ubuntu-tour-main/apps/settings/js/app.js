function showMenu(){
    parent.parent.showNotification("It's just a demo :)","","",1250);
}

function searchAnything(){
    parent.parent.showNotification("It's just a demo :)","","",1250);
}