newTab = () => {
    parent.parent.showNotification("It's just a demo :)","","",1250);
}

searchAnything = () => {
    parent.parent.showNotification("It's just a demo :)","","",1250);
}

openMenu = () => {
    parent.parent.showNotification("It's just a demo :)","","",1250);
}