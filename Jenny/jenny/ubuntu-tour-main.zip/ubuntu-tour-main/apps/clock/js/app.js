function reload(){
    document.querySelector(".content-iframe").src=document.querySelector(".content-iframe").src;
}

function showMenu(){
    parent.parent.showNotification("It's just a demo :)","","",1250);
}

function hourly(){
    parent.parent.showNotification("It's just a demo :)","","",1250);
}

function daily(){
    parent.parent.showNotification("It's just a demo :)","","",1250);
}