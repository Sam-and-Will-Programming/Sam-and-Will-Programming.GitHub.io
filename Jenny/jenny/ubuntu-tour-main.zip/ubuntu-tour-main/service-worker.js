self.addEventListener('install', function(e) {});
self.addEventListener("activate", event => {});
self.addEventListener('fetch', function (event){});