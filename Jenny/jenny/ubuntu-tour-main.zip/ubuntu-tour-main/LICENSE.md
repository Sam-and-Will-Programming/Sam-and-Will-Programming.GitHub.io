* This project licensed by [MPL2](./LICENSE.txt).

* css/UbuntuRegular.ttf licensed by [Ubuntu Font License](./LICENSE_UFL.txt).

* icons/Suru and assets licensed by [Creative Commons Attribution-ShareAlike 4.0 License](./LICENSE_CCBYSA.txt). (Read icons/Suru/README.md and cons/Suru/CONTRIBUTING.md to learn about)(Forked from https://github.com/ubuntu/yaru)

* icons/unsplash licensed by [Unsplash License](./LICENSE_UNSPLASH.txt). (Read icons/unsplash/Attribution.html to learn about)

* 7.css licensed by [MIT License](./LICENSE_MIT.css) [Github](https://github.com/khang-nd/7.css)

* Bootstrap Icons licensed by [Mit License](./LICENSE_MIT.txt)

* Brython licensed by [BSD-3-Clause License](./LICENCE_BSD3Clause.TXT)

* Also used Geolocation Services of [CodeTabs](https://github.com/jolav/codetabs)

> Ubuntu and Canonical are registered trademarks of Canonical Ltd.

> Gnome are registered trademarks of Gnome.

> WineHQ are registered trademarks of WineHQ.

> Python are registered trademarks of Python Software Foundation.

> LibreOffice are registered trademarks of The Document Foundation.